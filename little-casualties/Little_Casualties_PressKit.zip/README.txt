Little Casualties - Press Kit

Game: Little Casualties
Developer: Pixel Pending (solo developer)
Website: https://pixelpending.gg/little-casualties
Steam: https://store.steampowered.com/app/4535920/Little_Casualties/
Contact: hello@pixelpending.gg

----------------------------------------
ABOUT THE GAME
----------------------------------------

Little Casualties is a physics-based puzzle game where you guide named units to the exit using placeable tools, while their lineage carries across generations of permanent failure.

Players build solutions using bridges, catapults, kickers, and parachute dispensers to navigate chaotic levels filled with unpredictable outcomes. Each run generates new stories as units persist across generations.

----------------------------------------
DEMO CONTENT
----------------------------------------

Included in the demo:
- Classic Mode (selected levels)
- Outside biome
- The Moon
- Core tools and mechanics
- LCNN - live news coverage of every disaster
- Memorial Wall

----------------------------------------
FULL GAME FEATURES (NOT IN DEMO)
----------------------------------------

- Squad Mode (persistent roster, permadeath, lineage progression)
- Full Classic Mode campaign
- Additional biomes: Sawmill, Underground, City, Office Building
- 35 achievements
- Expanded systems and progression

----------------------------------------
TECHNICAL DETAILS
----------------------------------------

- Native support: Windows, macOS, Linux
- Lightweight build (currently ~30MB, expected under 100MB at launch)
- Runs on older hardware (tested on 10-year-old Linux laptop)
- Built in GameMaker from scratch

----------------------------------------
PRESS NOTES
----------------------------------------

Please feel free to use any screenshots, capsule art, or logos included in this press kit.

For additional assets, interviews, or keys, contact:
hello@pixelpending.gg

----------------------------------------

Made by one person.
No budget. No team.
Just a lot of pixels and a growing list of casualties.

Sorry, Gerald.